export const getStoreLink = () => {
  const ua = navigator.userAgent || navigator.vendor;

  if (/android/i.test(ua)) {
    return "https://play.google.com/store/apps/details?id=stemify";
  }

  if (/iPad|iPhone|iPod/.test(ua)) {
    return "https://apps.apple.com/app/stemify";
  }

  // default
  return "https://stemify.in/download";
};
