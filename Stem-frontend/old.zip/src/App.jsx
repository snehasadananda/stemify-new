import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import DynamicPage from "./pages/DynamicPage";

import Footer from "./components/Footer";

export default function App() {
  return (
    <BrowserRouter>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/page/:slug" element={<DynamicPage />} />
      </Routes>

      <Footer />

    </BrowserRouter>
  );
}
