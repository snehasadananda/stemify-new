import axios from "axios";

const API = "http://localhost:5000/api/pages";

export const getPage = async (slug) => {
  const res = await axios.get(`${API}/${slug}`);
  return res.data;
};