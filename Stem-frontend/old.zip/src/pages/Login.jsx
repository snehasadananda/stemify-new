import { useState, useContext } from "react";
import { AuthContext } from "../context/AuthContext";

import "../styles/theme.css";
import "../styles/login.css";

export default function Login() {

  const { login } = useContext(AuthContext);

  const [form, setForm] = useState({
    username: "",
    password: ""
  });

  const submit = async () => {
    try {
      await login(form);
      window.location = "/dashboard";
    } catch {
      alert("Invalid credentials");
    }
  };

  return (
  <div className="login-container">

    {/* LEFT ROBOT */}
    <div className="login-left">
      <img src="/robo.png" width="360" />
    </div>

    {/* RIGHT LOGIN */}
    <div className="login-right">

      <div className="card login-box">

        <img
          src="/STEMIFY logo.png"
          width="200"
          style={{ marginBottom: 20 }}
        />

        <input
          className="input"
          placeholder="Username"
          onChange={e =>
            setForm({...form, username:e.target.value})
          }
        />

        <input
          className="input"
          type="password"
          placeholder="Password"
          onChange={e =>
            setForm({...form, password:e.target.value})
          }
        />

        <button
          className="btn-purple"
          onClick={submit}
        >
          Login
        </button>

      </div>

    </div>
  </div>
  );
}
