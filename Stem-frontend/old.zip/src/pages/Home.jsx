import { useNavigate } from "react-router-dom";
import Robot from "../components/Robot";
import { getStoreLink } from "../utils/device";

export default function Home() {

  const nav = useNavigate();

  return (
    <div className="home">

      <h1>Welcome to STEMIFY AI</h1>

      <Robot />

      <div className="btn-group">

        <button onClick={() => nav("/login")}>
          Start Now
        </button>

        <button onClick={() => nav("/register")}>
          Signup
        </button>

        <button onClick={() =>
          window.location.href = getStoreLink()
        }>
          Get Stemify AI App
        </button>

      </div>

    </div>
  );
}
