import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getPage } from "../services/pageService";

export default function DynamicPage() {

  const { slug } = useParams();
  const [page, setPage] = useState({});

  useEffect(() => {
    getPage(slug).then(setPage);
  }, [slug]);

  return (
    <div className="content">
      <h2>{page.title}</h2>

      <div
        dangerouslySetInnerHTML={{
          __html: page.content
        }}
      />
    </div>
  );
}
