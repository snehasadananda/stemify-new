import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="footer">
      <div>
        <Link to="/page/privacy-policy">Privacy Policy</Link>
        <Link to="/page/terms">Terms & Conditions</Link>
        <Link to="/page/about">About Us</Link>
      </div>

      <div className="copy">
        © 2025 Stemify. All rights reserved.
      </div>
    </footer>
  );
}
