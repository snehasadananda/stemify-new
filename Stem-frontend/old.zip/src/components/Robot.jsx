import "../styles/main.css";
import robo from "../assets/robo.png";

export default function Robot() {
  return (
    <div className="robot-container">
      <img src={robo} className="floating-robot" />
    </div>
  );
}
